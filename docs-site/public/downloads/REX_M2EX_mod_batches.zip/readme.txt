These batch files launch Rome Total War mods using Rome Engine Extender (REX) instead of the original executables.
BI is for Barbarian Invasion mods, ALX is for Alexander mods.

SETUP:
1. Place the batch file inside your main directory (the folder containing the game files)
2. Open the batch file with a text editor (Notepad, Notepad++, etc.)
3. Replace "MODFOLDER" with the exact name of your mod folder
   If your mod folder name contains spaces (e.g., "My Mod Folder"), use quotes around the mod name (e.g., -mod:"My Mod Folder")
4. Save the file
5. Enjoy your mods