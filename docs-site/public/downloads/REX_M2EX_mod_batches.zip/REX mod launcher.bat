@echo off
start "" "%~dp0REX.exe" -mod:MODFOLDER -show_err