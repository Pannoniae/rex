These batch files launch Rome Total War mods using Rome Engine Extender (REX) instead of the original executables.
BI is for Barbarian Invasion mods, ALX is for Alexander mods.

See [link] for instructions.