@echo off
start "" "%~dp0REX.exe" -bi -mod:MODFOLDER -show_err