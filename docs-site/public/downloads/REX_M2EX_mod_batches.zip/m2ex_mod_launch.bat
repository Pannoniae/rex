cd ..\..
start M2EX.exe @mods\MODFOLDER\MOD.cfg