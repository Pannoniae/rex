@echo off
start "" "%~dp0REX.exe" -alx -mod:MODFOLDER -show_err